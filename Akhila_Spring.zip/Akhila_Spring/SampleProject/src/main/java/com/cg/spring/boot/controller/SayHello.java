package com.cg.spring.boot.controller;


@RestController
public class SayHello {
	    @RequestMapping("/hello")
	    public String hello() {
	    	return "hello!!!";
	    }
		
	
}
