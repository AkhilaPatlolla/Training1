package com.cg.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.dto.Product;
import com.cg.spring.repo.ProductRepo;
@Service("productservice")
public class ProductServiceImpl implements ProductService{
	@Autowired
	private ProductRepo repo;

	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return repo.getAllProducts();
	}

	@Override
	public Product getProductById(String id) {
		// TODO Auto-generated method stub
		return repo.getProductById(id);
	}

	@Override
	public void addProduct(Product p) {
		// TODO Auto-generated method stub
		repo.addProduct(p);
		
	}

	@Override
	public void deleteProduct(String id) {
		repo.deleteProduct(id);
	}

	@Override
	public void updateProduct(String id, Product p) {
		repo.updateProduct(id, p);
	}
	
}
