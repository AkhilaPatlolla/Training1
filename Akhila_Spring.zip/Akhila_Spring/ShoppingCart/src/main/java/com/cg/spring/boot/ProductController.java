package com.cg.spring.boot;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.spring.dto.Product;
import com.cg.spring.service.ProductService;

@RestController
public class ProductController {
	@Autowired
	private ProductService service;

	@RequestMapping("/products")
	public List<Product> Products() {
		return service.getAllProducts();
	}

	@RequestMapping("/products/{id}")
	public Product getProductById(@PathVariable String id) {
		return service.getProductById(id);

	}

	@RequestMapping(value = "/products", method = RequestMethod.POST)
	public void addProduct(@RequestBody Product p) {
		service.addProduct(p);
	}

	@RequestMapping(value = "/products/{id}", method = RequestMethod.DELETE)
	public void DeleteProduct(@PathVariable String id) {
		service.deleteProduct(id);
	}
	
	@RequestMapping(value = "/products/{id}", method = RequestMethod.PUT)
	public void UpdateProduct(@PathVariable String id,@RequestBody Product p) {
		service.updateProduct(id, p);
	}

}










