package com.cg.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.spring.dto.Customer;
import com.cg.spring.service.WalletService;

@RestController
public class WalletController {

	@Autowired
	private WalletService service;
	
	@RequestMapping(value="/createAccount", method=RequestMethod.POST)
	public void createAccount(@RequestBody Customer customerBean) {
		service.createAccount(customerBean);
	}
	
	@RequestMapping("/showAllCustomers")
	public List<Customer> showAllCustomers() {
		return service.showAllCustomers();
	}
	
	@RequestMapping("/showBalance/{custContact}")
	public double showBalance(@PathVariable String custContact){
		return service.showBalance(custContact);
	}
	
	@RequestMapping(value="/withdrawAcc/{custContact}/withdraw/{withdrawAmt}", method = RequestMethod.PUT)
	public void withdrawAmount(@PathVariable String custContact,@PathVariable double withdrawAmt) {
		service.withdrawAmount(custContact, withdrawAmt);
	}
	
	@RequestMapping(value="/depositAcc/{custContact}/deposit/{depositAmt}", method = RequestMethod.PUT)
	public void depositAmount(@PathVariable String custContact, @PathVariable double depositAmt) {
		service.depositAmount(custContact, depositAmt);
	}
	
	@RequestMapping(value="/fundTransfer/{senderCont}/{receiverCont}/{custAmt}", method = RequestMethod.PUT)
	public void fundTransfer(@PathVariable String senderCont,@PathVariable String receiverCont,@PathVariable double custAmt) {
		service.fundTransfer(senderCont, receiverCont, custAmt);
	}
	
	@RequestMapping("/printTransactions/{custContact}")
	public String printTransactions(@PathVariable String custContact) {
		return service.printTransactions(custContact);
	}
}
