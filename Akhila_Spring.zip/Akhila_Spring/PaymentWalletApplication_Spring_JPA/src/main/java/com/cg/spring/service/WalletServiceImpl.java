package com.cg.spring.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.dto.Customer;
import com.cg.spring.repo.WalletRepository;

@Service
public class WalletServiceImpl implements WalletService {

	@Autowired
	private WalletRepository repo;

	@Override
	public void createAccount(Customer customerBean) {
		String transaction = new String("Account Created On:\t" + LocalDateTime.now() + "\n");
		customerBean.setTransaction(transaction);
		repo.save(customerBean);
	}
	
	@Override
	public List<Customer> showAllCustomers() {
		List<Customer> allCustomers=new ArrayList<>();
		repo.findAll().forEach(allCustomers::add);
		return allCustomers;
	}

	@Override
	public double showBalance(String custContact) {
		Optional<Customer> customer = repo.findById(custContact);
		Customer customer1 = new Customer();
		if (customer.isPresent()) {
			customer1 = customer.get();
			return customer1.getBalance();
		}
		return customer1.getBalance();
	}

	@Override
	public void withdrawAmount(String custContact, double withdrawAmt) {
		Optional<Customer> customer = repo.findById(custContact);
		Customer customer2 = new Customer();
		if (customer.isPresent()) {
			customer2 = customer.get();
			customer2.setBalance(customer2.getBalance() - withdrawAmt);
			String transaction = new String(
					"Withdrawn\t" + withdrawAmt + "\t" + "Remaining Balance:\t" + customer2.getBalance() + "\n");
			customer2.setTransaction(transaction);
			repo.save(customer2);
		}
	}

	@Override
	public void depositAmount(String custContact, double depositAmt) {
		Optional<Customer> customer = repo.findById(custContact);
		if (customer.isPresent()) {
			Customer customer2 = new Customer();
			customer2 = customer.get();
			customer2.setBalance(customer2.getBalance() + depositAmt);
			String transaction = new String(
					"Deposited\t" + depositAmt + "\t" + "Remaining Balance:\t" + customer2.getBalance() + "\n");
			customer2.setTransaction(transaction);
			repo.save(customer2);
		}
	}

	@Override
	public void fundTransfer(String senderCont, String receiverCont, double custAmt) {
		Optional<Customer> customer = repo.findById(senderCont);
		Optional<Customer> customer1 = repo.findById(receiverCont);
		if (customer.isPresent() && customer1.isPresent()) {
			Customer sender = new Customer();
			Customer receiver = new Customer();
			sender = customer.get();
			receiver = customer1.get();
			sender.setBalance(sender.getBalance() - custAmt);
			String transactionSender = new String(
					"Withdrawn\t" + custAmt + "\t" + "Remaining Balance:\t" + sender.getBalance() + "\n");
			sender.setTransaction(transactionSender);

			receiver.setBalance(receiver.getBalance() + custAmt);
			String transactionReceiver = new String(
					"Deposited\t" + custAmt + "\t" + "Remaining Balance:\t" + receiver.getBalance() + "\n");
			receiver.setTransaction(transactionReceiver);
			repo.save(receiver);
			repo.save(sender);
		}
	}

	@Override
	public String printTransactions(String custContact) {
		Optional<Customer> cust = repo.findById(custContact);
		Customer customer = new Customer();
		if (cust.isPresent()) {
			customer = cust.get();
		}
		return customer.getTransaction();
	}
}
