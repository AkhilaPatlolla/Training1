package com.cg.spring.dto;


import javax.persistence.Entity;
import javax.persistence.Id;



@Entity
public class Customer{
	
	@Id

	private String mobileNo;
	
	private String name;

	private int age;

	private String emailId;
	
	private String gender;
	
	private double balance;
	
	private String transaction;

	public Customer() {
	}
	
	public Customer(String name, int age, String emailId, String gender, String mobileNo,
			double balance, String transaction) {
		super();
		this.name = name;
		this.age = age;
		this.emailId = emailId;
		this.gender = gender;
		this.mobileNo = mobileNo;
		this.balance = balance;
		this.transaction = transaction;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getTransaction() {
		return transaction;
	}

	public void setTransaction(String transaction) {
		this.transaction = transaction;
	}
}
