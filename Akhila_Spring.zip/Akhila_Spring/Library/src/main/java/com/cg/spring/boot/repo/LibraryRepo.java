package com.cg.spring.boot.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.spring.boot.beans.Library;

@Repository("library")
public interface LibraryRepo extends CrudRepository<Library, Integer> {

}
