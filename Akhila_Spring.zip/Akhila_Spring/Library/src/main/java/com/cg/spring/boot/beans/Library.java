package com.cg.spring.boot.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public class Library {
	 @Id  @GeneratedValue(strategy = GenerationType.AUTO)
	  

	private int bookId;
	private String bookName;
	private String dept;
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public Library(int bookId, String bookName, String dept) {
		super();
		this.bookId = bookId;
		this.bookName = bookName;
		this.dept = dept;
	}
	public Library() {
		super();
	}
	

}
