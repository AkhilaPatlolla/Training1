package com.cg.spring.boot.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.spring.boot.beans.Library;
import com.cg.spring.boot.service.LibraryService;
@RestController
public class LibraryController {
	@Autowired
	private LibraryService service;
	@RequestMapping("/library")
	public List<Library> Books() {
		return service.getAllBooks();
	}
	
	@RequestMapping("/library/{id}")
	public Optional<Library> getBookId(@PathVariable int id) {
		return service.getBookById(id);

	}

	@RequestMapping(value = "/library", method = RequestMethod.POST)
	public void addBook(@RequestBody Library l) {
		service.addBook(l);
	}

	@RequestMapping(value = "/library/{id}", method = RequestMethod.DELETE)
	public void DeleteBook(@PathVariable int id) {
		service.deleteBook(id);
	}
	
	@RequestMapping(value = "/library/{id}", method = RequestMethod.PUT)
	public void UpdateBook(@PathVariable int id,@RequestBody Library l) {
		service.updateBook(id, l);
	}
}
