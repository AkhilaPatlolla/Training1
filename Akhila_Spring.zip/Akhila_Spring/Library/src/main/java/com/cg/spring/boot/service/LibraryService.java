package com.cg.spring.boot.service;

import java.util.List;
import java.util.Optional;

import com.cg.spring.boot.beans.Library;


public interface LibraryService {
	public List<Library> getAllBooks();
	public Optional<Library> getBookById(int id);
	public void addBook(Library l);
	public void updateBook(int id,Library l);
	public void deleteBook(int id);
}
