package com.cg.wallet.service;

import java.math.BigDecimal;
import java.util.List;

import com.cg.wallet.bean.Customer;

public interface IWalletService {
	public Customer createAccount(String name,String mobileNo,BigDecimal amount);
	public BigDecimal showBalance(String mobileNo);
	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount);
	public Customer depositAmount(String mobileNo,BigDecimal amount);
}
