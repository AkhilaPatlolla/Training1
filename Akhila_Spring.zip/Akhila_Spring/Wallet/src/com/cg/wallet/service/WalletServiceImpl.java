package com.cg.wallet.service;

import java.math.BigDecimal;
import java.util.HashMap;


import com.cg.wallet.bean.Customer;
import com.cg.wallet.bean.Wallet;

public class WalletServiceImpl implements IWalletService{
	static HashMap<String, Customer> map = new HashMap<>();
	static Customer customer;
	static Wallet wallet; 
	
	
	
	
	@Override
	public Customer createAccount(String name, String mobileNo, BigDecimal amount) {
		return null;
		
	}

	@Override
	public BigDecimal showBalance(String mobileNo) {
		// TODO Auto-generated method stub
		return wallet.getBalance();
	}

	@Override
	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) {
		for(String key :map.keySet()) {
			Customer wallet1 = map.get(key);
			if(customer.getMobileNo().equals(sourceMobileNo) && customer.getMobileNo().equals(targetMobileNo)) {
				wallet.setBalance(wallet.getBalance() + amount);
				wallet.setBalance(balance);
			}
			
		}
		return key;
		
	}

	@Override
	public Customer depositAmount(String mobileNo, BigDecimal amount) {
		Customer cust = wallet.setBalance(wallet.getBalance().add(amount));
		return cust;
		
	}

}
