package com.cg.wallet.demo;

import java.math.BigDecimal;
import java.util.Scanner;

import com.cg.wallet.bean.Customer;
import com.cg.wallet.bean.Wallet;
import com.cg.wallet.service.IWalletService;

import com.cg.wallet.service.WalletServiceImpl;

public class App {
	
	public static void main(String[] args) {
		
		Customer customer = new Customer();
		Wallet wallet = new Wallet();
	
	int choice;
	
	Scanner scanner = new Scanner(System.in);
	System.out.println("Enter the choice");
	int ch = scanner.nextInt();
	do {
		printDetails();
		switch(ch) {
		case 1 :
			createAccount();
			break;
			
		case 2 :
			showBalance();
			break;
			
		case 3:
			fundTransfer();
			break;
			
		case 4 :
			depositAmount();
			break;
			
		case 5:
			System.exit(0);
			break;
		}
	
	
	
	}while(ch <= 5);
	
	
	
	}
	private static void printDetails() {
		System.out.println("1.Create account");
		System.out.println("2. Show Balance");
		System.out.println("3. Fund transfer");
		System.out.println("4. Deposit Amount");
		System.out.println("5. Exit");
		
	}
	
	
	
	
	
	public static void createAccount()
	{
		Customer customer = new Customer();
		Wallet wallet = new Wallet();
		IWalletService service = new WalletServiceImpl();
	    Scanner sc = new Scanner(System.in);
		System.out.println("Enter Name");
		String name = sc.next();
	    System.out.println("Enter Mobile Number");
		String mobileNo = sc.nextLine();
				
		System.out.println("Enter Opening Blanace");
		BigDecimal balance = sc.nextBigDecimal();
		customer.setName(name);
		customer.setMobileNo(mobileNo);
		wallet.setBalance(balance);	
		service.createAccount(name, mobileNo, balance);	
			
		
		
	}
	private static void showBalance() {
       Scanner scanner = new Scanner(System.in);
		
		IWalletService service = new WalletServiceImpl();
		System.out.println("Enter Mobile Number");
		String mobileNum = scanner.next();
		BigDecimal balance = service.showBalance(mobileNum);
			System.out.println("Account Balance is: "+balance);
		
	}
	
	private static void fundTransfer() {
		Scanner scanner = new Scanner(System.in);
		System.out.println(" Enter Source Mobile Number to transfer amount");
		String mobile1 = scanner.next();
		System.out.println(" Enter Target Mobile Number to transfer amount");
		String mobile2 = scanner.next();
		System.out.println("Enter Amount to Transfer");
		BigDecimal amount = scanner.nextBigDecimal();
		IWalletService service = new WalletServiceImpl();
		service.fundTransfer(mobile1,mobile2,amount);
		
	}
	
	private static void depositAmount() {
		Scanner scanner = new Scanner(System.in);
		IWalletService service = new WalletServiceImpl();
		System.out.println("Enter Mobile Number");
		String mobile = scanner.next();
		System.out.println("Enter amount to deposit");
		BigDecimal amount = scanner.nextBigDecimal();
	    service.depositAmount(mobile,amount);
	}
	
}
