package com.cg.wallet.repo;

import java.math.BigDecimal;

import com.cg.wallet.bean.Customer;

public interface IWalletRepo {
	public boolean save(Customer cutomer);
	public Customer findOne(String mobileNo);
}
