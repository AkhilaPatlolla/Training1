package com.cg.wallet.repo;

import java.math.BigDecimal;

import com.cg.wallet.bean.Customer;

public class WalletRepoImpl implements IWalletRepo{

	@Override
	public boolean save(Customer cutomer) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Customer findOne(String mobileNo) {
		// TODO Auto-generated method stub
		return null;
	}

	

}
