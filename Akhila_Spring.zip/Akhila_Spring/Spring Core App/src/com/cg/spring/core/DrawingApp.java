package com.cg.spring.core;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;

public class DrawingApp {

	public static void main(String[] args) {
		BeanFactory factory = new XmlBeanFactory(new FileSystemResource("spring.xml"));
		
		Shape s = (Shape) factory.getBean("circle");
		s.draw();
		
		/*Shape s = new Triangle();
		s.draw();
		
		Shape s1 = new Circle();
		s1.draw();*/
	}

}
