
package com.cg.spring.core.beans;

import org.springframework.stereotype.Component;

@Component("addr")
public class Address {
	public void print() {
		System.out.println("address of the customer");
	}
}
