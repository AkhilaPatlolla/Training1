package com.cg.spring.core.beans;

import java.util.List;

import javax.naming.spi.InitialContextFactory;

import org.omg.PortableInterceptor.DISCARDING;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Customer implements InitializingBean,DisposableBean{
	private int id;
	private String name;
	/*private Product product;*/
	
	private List<Product> list;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	/*public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}*/
	
	public void showProducts() {
		/*System.out.println("Product name: "+getProduct().getProduct_name());
		System.out.println("Product price: "+getProduct().getProduct_price());*/
		for(Product p :list) {
			System.out.println("=============================");
			System.out.println("name : "+p.getProduct_name());
			System.out.println("Price : "+p.getProduct_price());
			System.out.println("=============================");
		}
	}
	
	public List<Product> getList() {
		return list;
	}
	public void setList(List<Product> list) {
		this.list = list;
	}
	public void afterPropertiesSet() throws Exception {
		System.out.println("Init method for Customer");
	}
	public void destroy() throws Exception {
		System.out.println("Destroy method in Customer");
	}
	
	
}





















































