package com.cg.SampleProject1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
@ComponentScan(basePackages="com.cg")
@SpringBootApplication
public class SampleProject1Application {

	public static void main(String[] args) {
		SpringApplication.run(SampleProject1Application.class, args);
	}
}
