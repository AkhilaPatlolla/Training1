package com.cg.spring.ProductCartManagementSystem.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.spring.ProductCartManagementSystem.beans.Product;

@Repository
public interface IProductRepo extends CrudRepository<Product, String>{
	
}
