package com.cg.spring.ProductCartManagementSystem.service;

import java.util.List;

import com.cg.spring.ProductCartManagementSystem.beans.Product;
import com.cg.spring.ProductCartManagementSystem.exception.ProductException;

public interface IProductService {
	public List<Product> getAllProducts();
	public Product getProductById(String id) throws ProductException;
	public void addProduct(Product p);
	public void updateProduct(String id,Product p) throws ProductException;
	public void deleteProduct(String id) throws ProductException;
}
