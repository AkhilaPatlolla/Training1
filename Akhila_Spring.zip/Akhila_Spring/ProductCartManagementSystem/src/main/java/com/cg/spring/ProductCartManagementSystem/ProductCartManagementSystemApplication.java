package com.cg.spring.ProductCartManagementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductCartManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductCartManagementSystemApplication.class, args);
	}
}
