package com.cg.basic;

public class DrawingApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Triangle triangle = new Triangle();
		triangle.draw();

	}

}
