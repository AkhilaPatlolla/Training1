package com.cg.basic;

public class Triangle {
	public void draw() {
		System.out.println("drawing a triangle");
	}
	
	Point point = new Point(3,4);
}
