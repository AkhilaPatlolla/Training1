package com.cg.paymentwallet.controller;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.cg.paymentwallet.beans.Customer;
import com.cg.paymentwallet.beans.Wallet;
import com.cg.paymentwallet.exception.CustomerException;
import com.cg.paymentwallet.repo.IPaymentWalletRepo;
import com.cg.paymentwallet.service.PaymentWalletServiceImpl;

@RestController
public class PaymentWalletController {
	@Autowired
	PaymentWalletServiceImpl service;
	Customer customer;
	IPaymentWalletRepo repo;

	@RequestMapping("/customer")
	public List<Customer> Customers() {
		return service.getAllCustomers();
	}

	@RequestMapping("/customer/{mobileNumber}")
	public BigDecimal showBalance(@PathVariable String mobileNumber) {
		return service.showBalance(mobileNumber);
	}

	@RequestMapping(value = "/customer", method = RequestMethod.POST)
	public void addCustomer(@RequestBody Customer customer) {
		service.createAccount(customer);
	}

	@RequestMapping(value = "/customer/{mobileNumber}/d/{depositableAmount}", method = RequestMethod.PUT)
	public void depositMoney(@PathVariable String mobileNumber, @PathVariable BigDecimal depositableAmount) {
		service.deposit(mobileNumber, depositableAmount);
	}

	@RequestMapping(value = "/customer/{mobileNumber}/w/{withdrawableAmount}", method = RequestMethod.PUT)
	//@ResponseStatus(value=HttpStatus.NOT_FOUND,reason="Insufficient Balance to withdraw")
	//@ExceptionHandler({CustomerException.class})
	public void withdrawMoney(@PathVariable String mobileNumber, @PathVariable BigDecimal withdrawableAmount) throws CustomerException {
		try {
			if(withdrawableAmount.compareTo(customer.getWallet().getBalance()) < 0) {
				service.withdraw(mobileNumber, withdrawableAmount);
			}
		}
		catch(Exception e) {
		    throw new CustomerException("Insufficient Balance");
		}
			
		
	}

	@RequestMapping(value = "/customer/{mobileNumber}/print")
	public String printTransaction(@PathVariable String mobileNumber) {
		return service.printTransaction(mobileNumber);

	}

	@RequestMapping(value = "/customer/{SmobileNumber}/{RecmobileNumber}/{transferableAmount}", method = RequestMethod.PUT)
	public void fundTransfer(@PathVariable String SmobileNumber, @PathVariable String RecmobileNumber,
			@PathVariable BigDecimal transferableAmount) throws CustomerException {
		try {
			Customer customer = repo.findById(SmobileNumber).get();
			Customer customer1 = repo.findById(RecmobileNumber).get();
			if(transferableAmount.compareTo(customer.getWallet().getBalance())>0)
			    service.fundTransfer(SmobileNumber, RecmobileNumber, transferableAmount);
		}
		catch(Exception e) {
		    throw new CustomerException("Unable to transfer amount due to insufficient balance in "+customer.getNumber());
		}
	}

}
